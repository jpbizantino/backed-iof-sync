import { PartialType } from '@nestjs/mapped-types';
import { CreateDelavalDto } from './create-delaval.dto';

export class UpdateDelavalDto extends PartialType(CreateDelavalDto) {}
