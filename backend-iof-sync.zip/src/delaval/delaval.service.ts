import { Injectable } from '@nestjs/common';
import { CreateDelavalDto } from './dto/create-delaval.dto';
import { UpdateDelavalDto } from './dto/update-delaval.dto';

@Injectable()
export class DelavalService {
  create(createDelavalDto: CreateDelavalDto[]) {
    createDelavalDto.forEach((delaval, index) => {
      console.log('---registro ', index);
      console.log(delaval);
    });
  }

  findAll() {
    return `This action returns all delaval`;
  }

  findOne(id: number) {
    return `This action returns a #${id} delaval`;
  }

  update(id: number, updateDelavalDto: UpdateDelavalDto) {
    console.log(updateDelavalDto);
  }

  remove(id: number) {
    return `This action removes a #${id} delaval`;
  }
}
