import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { DelavalService } from './delaval.service';
import { CreateDelavalDto } from './dto/create-delaval.dto';
import { UpdateDelavalDto } from './dto/update-delaval.dto';

@Controller('delaval')
export class DelavalController {
  constructor(private readonly delavalService: DelavalService) {}

  @Post()
  create(@Body() createDelavalDto: CreateDelavalDto[]) {
    return this.delavalService.create(createDelavalDto);
  }

  @Get()
  findAll() {
    return this.delavalService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.delavalService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateDelavalDto: UpdateDelavalDto) {
    return this.delavalService.update(+id, updateDelavalDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.delavalService.remove(+id);
  }
}
